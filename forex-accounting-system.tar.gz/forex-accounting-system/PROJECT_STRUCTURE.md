# 專案結構說明

這份文件說明外匯會計系統的檔案結構和組織方式。

## 📁 目錄結構

\`\`\`
forex-accounting-system/
├── app/                          # Next.js App Router 目錄
│   ├── dashboard/               # 儀表板頁面
│   │   ├── layout.tsx          # 儀表板佈局（側邊欄、導航）
│   │   ├── page.tsx            # 儀表板首頁
│   │   ├── transactions/       # 外匯交易管理
│   │   │   └── page.tsx
│   │   ├── journal/            # 會計分錄管理
│   │   │   └── page.tsx
│   │   ├── reports/            # 財務報表
│   │   │   └── page.tsx
│   │   └── settings/           # 系統設定
│   │       └── page.tsx
│   ├── globals.css             # 全局樣式（Tailwind CSS）
│   ├── layout.tsx              # 根佈局
│   └── page.tsx                # 登入頁面
│
├── components/                  # React 組件（預留）
│   └── (可在此添加共用組件)
│
├── lib/                        # 工具函數和配置
│   └── supabase.ts            # Supabase 客戶端配置
│
├── types/                      # TypeScript 類型定義
│   └── index.ts               # 所有資料類型定義
│
├── utils/                      # 工具函數（預留）
│   └── (可在此添加輔助函數)
│
├── public/                     # 靜態資源
│   └── (圖片、字體等)
│
├── .env.local                  # 環境變量（不要提交到 Git）
├── .gitignore                  # Git 忽略檔案
├── database-setup.sql          # 資料庫設置腳本
├── netlify.toml               # Netlify 部署配置
├── next.config.js             # Next.js 配置
├── package.json               # 專案依賴
├── postcss.config.js          # PostCSS 配置
├── tailwind.config.js         # Tailwind CSS 配置
├── tsconfig.json              # TypeScript 配置
├── README.md                  # 專案說明文檔
├── DEPLOYMENT.md              # 部署指南
└── QUICKSTART.md              # 快速開始指南
\`\`\`

## 📄 主要檔案說明

### 配置檔案

| 檔案 | 用途 |
|------|------|
| \`package.json\` | 專案依賴和腳本定義 |
| \`next.config.js\` | Next.js 框架配置 |
| \`tailwind.config.js\` | Tailwind CSS 樣式配置 |
| \`tsconfig.json\` | TypeScript 編譯器配置 |
| \`netlify.toml\` | Netlify 部署設定 |
| \`.env.local\` | 環境變量（本地開發用） |

### 資料庫

| 檔案 | 用途 |
|------|------|
| \`database-setup.sql\` | 完整的資料庫設置腳本，包含所有表格、索引、觸發器和初始資料 |

### 應用程式核心

| 目錄/檔案 | 用途 |
|----------|------|
| \`app/page.tsx\` | 登入/註冊頁面 |
| \`app/layout.tsx\` | 根佈局（HTML 結構） |
| \`app/globals.css\` | 全局樣式和 Tailwind 自訂 |
| \`app/dashboard/\` | 所有儀表板相關頁面 |

### 工具和類型

| 目錄/檔案 | 用途 |
|----------|------|
| \`lib/supabase.ts\` | Supabase 客戶端初始化 |
| \`types/index.ts\` | TypeScript 介面定義 |

## 🎨 樣式系統

### Tailwind CSS 類別

專案使用 Tailwind CSS 提供的工具類，並在 \`globals.css\` 中定義了自訂組件：

- \`.btn\` - 按鈕基礎樣式
- \`.btn-primary\` - 主要按鈕
- \`.btn-secondary\` - 次要按鈕
- \`.card\` - 卡片容器
- \`.input\` - 輸入框
- \`.label\` - 標籤
- \`.table\` - 表格
- \`.badge\` - 徽章

### 顏色系統

在 \`tailwind.config.js\` 中定義了自訂顏色：
- \`primary\` - 藍色系（品牌主色）
- \`success\` - 綠色系（成功狀態）
- \`danger\` - 紅色系（危險/錯誤）

## 🗂️ 路由結構

### 公開路由
- \`/\` - 登入頁面

### 受保護路由（需要認證）
- \`/dashboard\` - 儀表板首頁
- \`/dashboard/transactions\` - 外匯交易管理
- \`/dashboard/journal\` - 會計分錄
- \`/dashboard/reports\` - 財務報表
- \`/dashboard/settings\` - 系統設定

## 🔑 環境變量

在 \`.env.local\` 中定義：

\`\`\`env
NEXT_PUBLIC_SUPABASE_URL        # Supabase 專案網址
NEXT_PUBLIC_SUPABASE_ANON_KEY   # Supabase 公開 API 金鑰
NEXT_PUBLIC_APP_NAME            # 應用程式名稱
NEXT_PUBLIC_APP_URL             # 應用程式網址
\`\`\`

## 🗃️ 資料庫表格

### 核心表格
1. \`user_roles\` - 用戶角色定義
2. \`user_profiles\` - 用戶資料
3. \`exchange_rates\` - 匯率資料
4. \`chart_of_accounts\` - 會計科目表
5. \`forex_transactions\` - 外匯交易
6. \`journal_entries\` - 會計分錄主檔
7. \`journal_entry_lines\` - 會計分錄明細
8. \`audit_logs\` - 審計日誌

詳細結構請參考 \`database-setup.sql\`

## 📦 依賴套件

### 主要依賴
- \`next\` - React 框架
- \`react\` & \`react-dom\` - React 核心
- \`@supabase/supabase-js\` - Supabase 客戶端
- \`tailwindcss\` - CSS 框架
- \`typescript\` - 型別系統
- \`lucide-react\` - 圖標庫
- \`date-fns\` - 日期處理
- \`recharts\` - 圖表庫

## 🛠️ 開發工作流程

### 添加新頁面
1. 在 \`app/dashboard/\` 下創建新目錄
2. 創建 \`page.tsx\` 檔案
3. 在 \`app/dashboard/layout.tsx\` 的 \`menuItems\` 中添加路由

### 添加新功能
1. 定義 TypeScript 類型（\`types/index.ts\`）
2. 創建必要的資料庫表格（更新 \`database-setup.sql\`）
3. 實作 UI 組件
4. 添加 Supabase 查詢邏輯

### 樣式自訂
1. 更新 \`tailwind.config.js\` 添加顏色或字體
2. 在 \`globals.css\` 中定義新的組件類別
3. 使用 Tailwind 工具類組合樣式

## 📝 命名規範

- **檔案名稱**: kebab-case（例如：\`user-profile.tsx\`）
- **組件名稱**: PascalCase（例如：\`UserProfile\`）
- **函數名稱**: camelCase（例如：\`getUserProfile\`）
- **常數**: UPPER_SNAKE_CASE（例如：\`API_BASE_URL\`）
- **資料庫表格**: snake_case（例如：\`user_profiles\`）

## 🔄 資料流程

\`\`\`
用戶操作
    ↓
React 組件
    ↓
Supabase Client (lib/supabase.ts)
    ↓
Supabase API
    ↓
PostgreSQL 資料庫（帶 RLS）
    ↓
返回資料
    ↓
更新 UI
\`\`\`

## 🚀 建議的擴展方向

### 短期（1-2 週）
- 添加資料驗證
- 實作錯誤處理機制
- 添加載入狀態

### 中期（1 個月）
- Excel 匯入/匯出
- 進階搜尋和篩選
- 圖表視覺化

### 長期（3 個月+）
- 多語言支援
- 行動版 App
- 即時通知系統

## 📚 推薦學習資源

- [Next.js 文檔](https://nextjs.org/docs)
- [Supabase 文檔](https://supabase.com/docs)
- [Tailwind CSS 文檔](https://tailwindcss.com/docs)
- [TypeScript 手冊](https://www.typescriptlang.org/docs/)

---

這個結構設計讓專案易於維護和擴展。如有任何問題，請參考各個配置檔案中的註解。
