# 外匯會計系統 (Forex Accounting System)

專業的外匯匯兌會計財務管理系統，提供完整的交易記錄、會計分錄、財務報表與權限管理功能。

## 🌟 主要功能

### 1. 用戶認證與權限管理
- ✅ 安全的登入/註冊系統
- ✅ 多層級角色權限控制（系統管理員、財務經理、會計人員、查詢人員）
- ✅ 用戶資料管理
- ✅ Row Level Security (RLS) 資料庫安全

### 2. 外匯交易管理
- ✅ 外匯買入/賣出/兌換交易記錄
- ✅ 即時匯率追蹤與管理
- ✅ 交易狀態管理（待處理、已完成、已取消）
- ✅ 多幣別支援（USD、EUR、JPY、CNY、TWD等）
- ✅ 銀行與交易編號追蹤

### 3. 會計分錄
- ✅ 會計科目表管理
- ✅ 自動或手動建立會計分錄
- ✅ 借貸平衡驗證
- ✅ 分錄狀態管理（草稿、已過帳、已作廢）

### 4. 財務報表
- ✅ 資產負債表
- ✅ 損益表
- ✅ 現金流量表（開發中）
- ✅ 多期間報表比較

### 5. 系統設定
- ✅ 個人資料設定
- ✅ 幣別管理
- ✅ 安全性設定
- ✅ 系統參數配置

## 🛠️ 技術架構

### 前端
- **Next.js 14** - React 框架，使用 App Router
- **TypeScript** - 型別安全
- **Tailwind CSS** - 現代化 UI 設計
- **Lucide React** - 圖標庫
- **date-fns** - 日期處理
- **Recharts** - 圖表視覺化

### 後端與資料庫
- **Supabase** - PostgreSQL 資料庫與認證服務
- **Row Level Security (RLS)** - 資料庫層級權限控制
- **PostgreSQL Triggers** - 自動更新時間戳記

### 部署
- **Netlify** - 前端部署平台
- **Supabase Cloud** - 資料庫託管

## 📦 安裝步驟

### 1. 克隆專案
\`\`\`bash
git clone <your-repository-url>
cd forex-accounting-system
\`\`\`

### 2. 安裝依賴
\`\`\`bash
npm install
\`\`\`

### 3. 設置環境變量
創建 \`.env.local\` 文件並填入以下內容：
\`\`\`env
NEXT_PUBLIC_SUPABASE_URL=https://ooheiofjailthttunjdk.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9vaGVpb2ZqYWlsdGh0dHVuamRrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjcxNTM3NTUsImV4cCI6MjA4MjcyOTc1NX0.xEtaCI5-DKtFg-3gvWalf4m2h4WKcx7pZJTmtwiMAwE
NEXT_PUBLIC_APP_NAME=外匯會計系統
NEXT_PUBLIC_APP_URL=http://localhost:3000
\`\`\`

### 4. 設置資料庫
1. 登入 [Supabase Dashboard](https://app.supabase.com)
2. 選擇您的專案
3. 前往 SQL Editor
4. 執行 \`database-setup.sql\` 中的所有 SQL 指令
5. 確認所有表格和資料都已正確建立

### 5. 本地開發
\`\`\`bash
npm run dev
\`\`\`

應用程式將在 [http://localhost:3000](http://localhost:3000) 啟動

## 🚀 部署到 Netlify

### 方法 1: 使用 Netlify CLI

1. 安裝 Netlify CLI
\`\`\`bash
npm install -g netlify-cli
\`\`\`

2. 登入 Netlify
\`\`\`bash
netlify login
\`\`\`

3. 初始化專案
\`\`\`bash
netlify init
\`\`\`

4. 設置環境變量
\`\`\`bash
netlify env:set NEXT_PUBLIC_SUPABASE_URL "https://ooheiofjailthttunjdk.supabase.co"
netlify env:set NEXT_PUBLIC_SUPABASE_ANON_KEY "your-anon-key"
\`\`\`

5. 部署
\`\`\`bash
netlify deploy --prod
\`\`\`

### 方法 2: 使用 Git 整合

1. 將程式碼推送到 GitHub
\`\`\`bash
git init
git add .
git commit -m "Initial commit"
git remote add origin <your-github-repo-url>
git push -u origin main
\`\`\`

2. 登入 [Netlify](https://app.netlify.com)
3. 點擊 "New site from Git"
4. 選擇您的 GitHub 儲存庫
5. 設置建置指令：
   - Build command: \`npm run build\`
   - Publish directory: \`.next\`
6. 添加環境變量（在 Site settings > Environment variables）
7. 點擊 "Deploy site"

## 📋 資料庫結構

### 主要資料表

1. **user_roles** - 用戶角色
2. **user_profiles** - 用戶資料
3. **exchange_rates** - 匯率資料
4. **chart_of_accounts** - 會計科目表
5. **forex_transactions** - 外匯交易
6. **journal_entries** - 會計分錄
7. **journal_entry_lines** - 會計分錄明細
8. **audit_logs** - 審計日誌

詳細結構請參考 \`database-setup.sql\`

## 👥 預設用戶角色

系統預設建立以下角色：

- **系統管理員** - 擁有所有系統權限
- **財務經理** - 可以審核和核准交易
- **會計人員** - 可以創建和編輯交易
- **查詢人員** - 只能查看數據

## 🔐 安全性

- ✅ Supabase 認證系統
- ✅ Row Level Security (RLS) 政策
- ✅ JWT Token 驗證
- ✅ HTTPS 加密傳輸
- ✅ 密碼加密儲存
- ✅ 審計日誌追蹤

## 📱 響應式設計

系統完全支援：
- 💻 桌面電腦
- 📱 平板電腦
- 📱 手機

## 🎨 UI/UX 特色

- 現代化玻璃擬態設計
- 流暢的動畫效果
- 直覺的操作介面
- 清晰的視覺層次
- 專業的財務系統外觀

## 🔧 開發指令

\`\`\`bash
# 開發環境
npm run dev

# 建置生產版本
npm run build

# 啟動生產版本
npm run start

# 程式碼檢查
npm run lint
\`\`\`

## 📝 待辦功能

- [ ] Excel 匯入/匯出
- [ ] 進階財務分析圖表
- [ ] 多語言支援
- [ ] 電子郵件通知
- [ ] 批次交易處理
- [ ] 更多財務報表類型
- [ ] 行動版 App

## 🤝 貢獻

歡迎提交 Issue 或 Pull Request！

## 📄 授權

此專案採用 MIT 授權

## 📞 聯絡資訊

如有任何問題，請聯繫專案維護者。

---

**建立日期**: 2026年1月
**版本**: 1.0.0
**作者**: Your Name

## 🎯 快速開始

1. 執行資料庫設置腳本
2. 設置環境變量
3. 安裝依賴並啟動開發伺服器
4. 使用註冊功能創建第一個帳戶
5. 開始管理外匯交易！

祝您使用愉快！ 🎉
